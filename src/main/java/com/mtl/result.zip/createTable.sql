
create table Student
(
  no varchar2(11),
  name varchar2(20),
  age number(4),
  height number(5, 2),
  gender varchar2(2),
  weight number(5, 2),
  clazz varchar2(20),
  tellNum varchar2(11)
)
;

create table Class
(
  no varchar2(11),
  location varchar2(128),
  level varchar2(6)
)
;
