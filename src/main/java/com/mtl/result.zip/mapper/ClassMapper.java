package com.mtl.mapper;

import org.apache.ibatis.annotations.Insert;
import com.mtl.pojo.Class;

public interface ClassMapper {
    @Insert("insert into Class values (#{no}, #{location}, #{level})")
    int insert(Class object);
}