package com.mtl.mapper;

import org.apache.ibatis.annotations.Insert;
import com.mtl.pojo.Student;

public interface StudentMapper {
    @Insert("insert into Student values (#{no}, #{name}, #{age}, #{height}, #{gender}, #{weight}, #{clazz}, #{tellNum})")
    int insert(Class object);
}